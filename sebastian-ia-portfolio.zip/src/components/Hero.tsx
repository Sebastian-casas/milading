import { useEffect, useState } from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';

const prompts = [
  '> generando secuencia cinematica, lente 35mm, luz dorada...',
  '> renderizando 24fps — estilo: foto realista...',
  '> aplicando coherencia de personaje entre tomas...',
  '> exportando master 4K para color grading...',
];

export default function Hero() {
  const [lineIndex, setLineIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [lines, setLines] = useState<string[]>([]);

  useEffect(() => {
    if (lineIndex >= prompts.length) return;
    const current = prompts[lineIndex];

    if (charIndex < current.length) {
      const t = setTimeout(() => setCharIndex((c) => c + 1), 28);
      return () => clearTimeout(t);
    } else {
      const t = setTimeout(() => {
        setLines((prev) => [...prev, current]);
        setLineIndex((i) => i + 1);
        setCharIndex(0);
      }, 600);
      return () => clearTimeout(t);
    }
  }, [charIndex, lineIndex]);

  const cycleComplete = lineIndex >= prompts.length;

  return (
    <section
      id="top"
      className="relative min-h-screen flex flex-col justify-center px-6 md:px-10 pt-28 pb-16 overflow-hidden"
    >
      {/* background grid */}
      <div
        className="absolute inset-0 opacity-[0.07] pointer-events-none"
        style={{
          backgroundImage:
            'linear-gradient(to right, #EF00FF 1px, transparent 1px), linear-gradient(to bottom, #EF00FF 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />
      <div className="absolute -top-32 -right-32 w-[28rem] h-[28rem] bg-magenta/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <div className="grid lg:grid-cols-[1.4fr_1fr] gap-12 items-end">
          <div>
            <div className="flex items-center gap-2 mb-6 font-mono text-xs uppercase tracking-[0.3em] text-magenta">
              <Sparkles size={14} />
              Laboratorio Creativo · IA generativa
            </div>

            <h1 className="font-head leading-[0.95] uppercase">
              <span className="block text-[clamp(3.2rem,11vw,8rem)] text-bone">Creo lo que</span>
              <span className="block text-[clamp(3.2rem,11vw,8rem)] text-stroke">no existe</span>
              <span className="block text-[clamp(3.2rem,11vw,8rem)] text-bone">
                todav<span className="text-magenta">í</span>a.
              </span>
            </h1>

            <p className="font-body text-lg md:text-xl text-smoke max-w-xl mt-8 leading-relaxed">
              Soy Sebastián: dirijo proyectos de video, imagen y diseño usando
              modelos de inteligencia artificial como herramienta principal de
              producción. Esto es un registro de lo que he generado, editado y
              lanzado.
            </p>

            <div className="flex flex-wrap gap-4 mt-10">
              <a
                href="#trabajo"
                className="font-mono text-sm uppercase tracking-widest bg-magenta text-ink px-6 py-3 hover:bg-bone transition-colors"
              >
                Ver proyectos
              </a>
              <a
                href="#contacto"
                className="font-mono text-sm uppercase tracking-widest border border-line text-bone px-6 py-3 hover:border-magenta transition-colors"
              >
                Hablemos de tu marca
              </a>
            </div>
          </div>

          {/* Signature element: terminal de generación */}
          <div className="bg-panel border border-line rounded-lg overflow-hidden shadow-2xl shadow-black/50 w-full">
            <div className="flex items-center gap-2 px-4 py-3 border-b border-line bg-ink/60">
              <span className="w-3 h-3 rounded-full bg-[#FF5F56]" />
              <span className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
              <span className="w-3 h-3 rounded-full bg-[#27C93F]" />
              <span className="font-mono text-xs text-smoke ml-3">sebastian_IA — generador</span>
            </div>
            <div className="p-5 font-mono text-sm md:text-[0.85rem] space-y-2 min-h-[220px]">
              {lines.map((l, i) => (
                <p key={i} className="text-magenta/80">
                  {l}
                </p>
              ))}
              {!cycleComplete && (
                <p className="text-magenta/80">
                  {prompts[lineIndex].slice(0, charIndex)}
                  <span className="cursor-blink">▌</span>
                </p>
              )}
              {cycleComplete && (
                <p className="text-bone">
                  output: <span className="text-magenta">render_final.mp4</span> listo
                  <span className="cursor-blink ml-1">▌</span>
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="mt-20 flex items-center gap-3 font-mono text-xs uppercase tracking-[0.3em] text-smoke">
          <ArrowDown size={14} className="text-magenta" />
          Desplázate para ver el trabajo
        </div>
      </div>
    </section>
  );
}
