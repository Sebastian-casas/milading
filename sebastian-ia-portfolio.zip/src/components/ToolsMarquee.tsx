const tools = [
  'RUNWAY', 'MIDJOURNEY', 'SORA', 'KLING AI', 'VEO', 'STABLE DIFFUSION',
  'LUMA', 'ELEVENLABS', 'DAVINCI RESOLVE', 'FLUX', 'PIKA', 'SUNO',
];

export default function ToolsMarquee() {
  const loop = [...tools, ...tools];
  return (
    <div className="border-y border-line bg-panel overflow-hidden">
      <div className="flex whitespace-nowrap animate-marquee">
        {loop.map((t, i) => (
          <span
            key={i}
            className="font-head text-3xl md:text-4xl uppercase px-8 py-5 text-smoke/40 flex items-center gap-8"
          >
            {t}
            <span className="text-magenta text-xl">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
