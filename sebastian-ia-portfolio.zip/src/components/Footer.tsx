export default function Footer() {
  return (
    <footer className="px-6 md:px-10 py-10 border-t border-line max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-xs uppercase tracking-widest text-smoke">
      <div className="flex items-center gap-3">
        <img src="/logo.jpg" alt="Sebastian IA" className="h-8 w-8 rounded-full object-cover" />
        <span>
          Sebast<span className="text-magenta">IA</span>n · Laboratorio Creativo
        </span>
      </div>
      <span>© {new Date().getFullYear()} — Hecho con IA y mucho café</span>
    </footer>
  );
}
