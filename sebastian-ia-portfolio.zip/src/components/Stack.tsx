import { skills } from '../data/projects';

export default function Stack() {
  return (
    <section id="stack" className="px-6 md:px-10 py-24 max-w-7xl mx-auto border-t border-line">
      <span className="font-mono text-xs uppercase tracking-[0.3em] text-magenta">04 — Caja de herramientas</span>
      <h2 className="font-head text-5xl md:text-6xl uppercase mt-2 mb-14">
        Stack <span className="text-stroke">creativo</span>
      </h2>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {skills.map((s) => (
          <div
            key={s.name}
            className="border border-line p-6 hover:border-magenta transition-colors bg-panel"
          >
            <h3 className="font-head text-xl uppercase mb-2">{s.name}</h3>
            <p className="font-mono text-sm text-smoke">{s.detail}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
