import { Play } from 'lucide-react';
import { categoryLabels } from '../data/projects';
import type { Project } from '../data/projects';

export default function ProjectCard({ project }: { project: Project }) {
  return (
    <article className="group border border-line bg-panel hover:border-magenta transition-colors duration-300 flex flex-col">
      <div className="relative aspect-video bg-ink overflow-hidden">
        {project.videoUrl ? (
          <iframe
            src={project.videoUrl}
            title={project.title}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            loading="lazy"
          />
        ) : (
          <img
            src={project.thumbnail}
            alt={project.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        )}
        {!project.videoUrl && (
          <div className="absolute inset-0 flex items-center justify-center bg-ink/0 group-hover:bg-ink/40 transition-colors">
            <Play
              size={36}
              className="text-magenta opacity-0 group-hover:opacity-100 transition-opacity"
            />
          </div>
        )}
      </div>

      <div className="p-5 flex flex-col gap-3 flex-1">
        <div className="flex items-center justify-between font-mono text-xs uppercase tracking-widest text-magenta">
          <span>{categoryLabels[project.category]}</span>
          <span className="text-smoke">{project.year}</span>
        </div>
        <h3 className="font-head text-2xl uppercase leading-tight">{project.title}</h3>
        <p className="text-smoke text-sm leading-relaxed flex-1">{project.description}</p>
        <div className="font-mono text-xs text-smoke/70 pt-2 border-t border-line">
          herramienta: <span className="text-bone">{project.tool}</span>
        </div>
      </div>
    </article>
  );
}
