import { useState } from 'react';
import { projects, categoryLabels } from '../data/projects';
import type { ProjectCategory } from '../data/projects';
import ProjectCard from './ProjectCard';

const categories: (ProjectCategory | 'todos')[] = ['todos', 'video', 'imagen', 'diseno', 'web'];

export default function Work() {
  const [active, setActive] = useState<ProjectCategory | 'todos'>('todos');

  const filtered = active === 'todos' ? projects : projects.filter((p) => p.category === active);

  return (
    <section id="trabajo" className="px-6 md:px-10 py-24 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
        <div>
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-magenta">02 — Selección</span>
          <h2 className="font-head text-5xl md:text-6xl uppercase mt-2">
            Trabajo <span className="text-stroke">reciente</span>
          </h2>
        </div>

        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`font-mono text-xs uppercase tracking-widest px-4 py-2 border transition-colors ${
                active === c
                  ? 'bg-magenta text-ink border-magenta'
                  : 'border-line text-smoke hover:border-magenta hover:text-bone'
              }`}
            >
              {c === 'todos' ? 'Todos' : categoryLabels[c]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((p) => (
          <ProjectCard key={p.id} project={p} />
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="text-smoke font-mono text-sm">Aún no hay proyectos en esta categoría.</p>
      )}
    </section>
  );
}
