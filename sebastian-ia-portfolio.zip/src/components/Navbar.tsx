import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  { href: '#trabajo', label: 'Trabajo' },
  { href: '#proceso', label: 'Proceso' },
  { href: '#stack', label: 'Stack' },
  { href: '#contacto', label: 'Contacto' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? 'bg-ink/90 backdrop-blur-md border-b border-line' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10 h-20 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-3 group">
          <img
            src="/logo.jpg"
            alt="Sebastian IA"
            className="h-10 w-10 rounded-full object-cover ring-1 ring-line group-hover:ring-magenta transition-colors"
          />
          <span className="font-display text-xl tracking-wide hidden sm:inline">
            Sebast<span className="text-magenta">IA</span>n
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-10">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="font-mono text-sm uppercase tracking-widest text-smoke hover:text-bone transition-colors relative group"
            >
              {l.label}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-magenta transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <a
            href="#contacto"
            className="font-mono text-sm uppercase tracking-widest border border-magenta text-magenta px-4 py-2 hover:bg-magenta hover:text-ink transition-colors"
          >
            Cotiza tu proyecto
          </a>
        </nav>

        <button
          className="md:hidden text-bone"
          onClick={() => setOpen(!open)}
          aria-label="Abrir menú"
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-ink border-t border-line px-6 py-6 flex flex-col gap-5">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="font-mono text-sm uppercase tracking-widest text-smoke hover:text-bone"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contacto"
            onClick={() => setOpen(false)}
            className="font-mono text-sm uppercase tracking-widest border border-magenta text-magenta px-4 py-2 text-center"
          >
            Cotiza tu proyecto
          </a>
        </div>
      )}
    </header>
  );
}
