const steps = [
  {
    n: '01',
    title: 'Brief y dirección',
    text: 'Definimos la idea, el tono y las referencias visuales. Aquí se decide qué modelos y estilos generativos se ajustan mejor al objetivo.',
  },
  {
    n: '02',
    title: 'Generación',
    text: 'Producción de imágenes y video con modelos de IA: iteración de prompts, control de consistencia visual y selección de las mejores tomas.',
  },
  {
    n: '03',
    title: 'Curaduría',
    text: 'De decenas de variantes generadas, se seleccionan las que realmente funcionan para la narrativa o la pieza final.',
  },
  {
    n: '04',
    title: 'Postproducción',
    text: 'Edición, color, sonido y composición final en herramientas tradicionales, para que el resultado se vea pulido y listo para publicar.',
  },
];

export default function Process() {
  return (
    <section id="proceso" className="px-6 md:px-10 py-24 max-w-7xl mx-auto border-t border-line">
      <span className="font-mono text-xs uppercase tracking-[0.3em] text-magenta">03 — Cómo trabajo</span>
      <h2 className="font-head text-5xl md:text-6xl uppercase mt-2 mb-14">
        De la idea al <span className="text-stroke">render final</span>
      </h2>

      <div className="grid md:grid-cols-2 gap-px bg-line border border-line">
        {steps.map((s) => (
          <div key={s.n} className="bg-ink p-8 md:p-10 flex flex-col gap-4">
            <span className="font-display text-4xl text-magenta">{s.n}</span>
            <h3 className="font-head text-2xl uppercase">{s.title}</h3>
            <p className="text-smoke leading-relaxed">{s.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
