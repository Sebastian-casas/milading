import { socials } from '../data/projects';
import { ArrowUpRight } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contacto" className="px-6 md:px-10 py-24 max-w-7xl mx-auto border-t border-line">
      <div className="grid lg:grid-cols-[1.3fr_1fr] gap-12 items-start">
        <div>
          <span className="font-mono text-xs uppercase tracking-[0.3em] text-magenta">05 — Contacto</span>
          <h2 className="font-head text-5xl md:text-7xl uppercase mt-2 leading-[1.05]">
            ¿Tienes una idea que <span className="text-stroke">aún no existe</span>?
          </h2>
          <p className="text-smoke text-lg mt-6 max-w-lg leading-relaxed">
            Escríbeme y cuéntame qué quieres crear: un video, una campaña, una
            identidad visual o algo que aún no tiene nombre. Lo construimos
            con IA.
          </p>

          <a
            href="mailto:hola@sebastianlab.cl"
            className="inline-flex items-center gap-2 mt-8 font-mono text-sm uppercase tracking-widest bg-magenta text-ink px-6 py-4 hover:bg-bone transition-colors"
          >
            hola@sebastianlab.cl
            <ArrowUpRight size={16} />
          </a>
        </div>

        <div className="flex flex-col gap-px bg-line border border-line">
          {socials.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noreferrer"
              className="bg-ink px-6 py-5 flex items-center justify-between font-mono text-sm uppercase tracking-widest text-smoke hover:text-magenta hover:bg-panel transition-colors group"
            >
              {s.label}
              <ArrowUpRight size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
