import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ToolsMarquee from './components/ToolsMarquee';
import Work from './components/Work';
import Process from './components/Process';
import Stack from './components/Stack';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="noise bg-ink min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <ToolsMarquee />
        <Work />
        <Process />
        <Stack />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
