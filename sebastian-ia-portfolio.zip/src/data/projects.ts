export type ProjectCategory = 'video' | 'imagen' | 'diseno' | 'web';

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  tool: string;
  description: string;
  // Para videos: URL de embed (YouTube/Vimeo) o ruta a archivo mp4 en /public
  videoUrl?: string;
  // Para imagen/portada
  thumbnail?: string;
  year: string;
  featured?: boolean;
}

export const categoryLabels: Record<ProjectCategory, string> = {
  video: 'Video IA',
  imagen: 'Imagen IA',
  diseno: 'Diseño',
  web: 'Desarrollo',
};

// EDITA O AGREGA TUS PROYECTOS AQUÍ
export const projects: Project[] = [
  {
    id: 'proyecto-01',
    title: 'Reemplaza este título',
    category: 'video',
    tool: 'Runway / Veo / Sora',
    description:
      'Descripción corta del proyecto: qué se generó, qué herramienta de IA se usó y el objetivo creativo detrás de la pieza.',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    year: '2026',
    featured: true,
  },
  {
    id: 'proyecto-02',
    title: 'Otro proyecto de video',
    category: 'video',
    tool: 'Kling AI',
    description:
      'Pieza experimental generada con modelos de difusión de video, explorando narrativa visual y transiciones imposibles.',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    year: '2026',
  },
  {
    id: 'proyecto-03',
    title: 'Serie de imágenes conceptuales',
    category: 'imagen',
    tool: 'Midjourney',
    description:
      'Exploración visual de un universo estético propio, usado como base para storyboards de video generativo.',
    thumbnail: '/logo.jpg',
    year: '2025',
  },
  {
    id: 'proyecto-04',
    title: 'Identidad visual de marca',
    category: 'diseno',
    tool: 'Figma + IA',
    description:
      'Sistema de marca completo: logotipo, paleta, tipografía y aplicaciones, apoyado en herramientas de IA para exploración rápida de conceptos.',
    thumbnail: '/logo.jpg',
    year: '2025',
  },
  {
    id: 'proyecto-05',
    title: 'Landing page interactiva',
    category: 'web',
    tool: 'React + Tailwind',
    description:
      'Sitio web a medida con animaciones, copy y estructura pensados para conversión, construido con asistencia de IA en el desarrollo.',
    thumbnail: '/logo.jpg',
    year: '2025',
  },
  {
    id: 'proyecto-06',
    title: 'Cortometraje experimental',
    category: 'video',
    tool: 'Runway Gen-3',
    description:
      'Pieza narrativa corta generada y editada íntegramente con herramientas de video por IA, combinando varios clips generativos.',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    year: '2024',
  },
];

export const skills = [
  { name: 'Video generativo', detail: 'Runway, Kling, Sora, Veo, Luma' },
  { name: 'Imagen generativa', detail: 'Midjourney, Stable Diffusion, Flux' },
  { name: 'Edición y postproducción', detail: 'Premiere, DaVinci Resolve, After Effects' },
  { name: 'Diseño de marca', detail: 'Identidad visual, branding, motion' },
  { name: 'Desarrollo web', detail: 'React, Tailwind, automatización con IA' },
  { name: 'Prompt engineering', detail: 'Dirección creativa para modelos generativos' },
];

export const socials = [
  { label: 'Instagram', href: 'https://instagram.com/' },
  { label: 'YouTube', href: 'https://youtube.com/' },
  { label: 'TikTok', href: 'https://tiktok.com/' },
  { label: 'WhatsApp', href: 'https://wa.me/56900000000' },
];
